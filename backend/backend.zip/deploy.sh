#!/bin/bash

# Exit on error
set -e

echo "Starting deployment process..."

# Update system packages
echo "Updating system packages..."
sudo yum update -y

# Install Node.js if not installed
if ! command -v node &> /dev/null; then
    echo "Installing Node.js..."
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash
    . ~/.nvm/nvm.sh
    nvm install 16
    nvm use 16
fi

# Install PM2 if not installed
if ! command -v pm2 &> /dev/null; then
    echo "Installing PM2..."
    npm install -g pm2
fi

# Create app directory if it doesn't exist
echo "Setting up application directory..."
mkdir -p ~/app/backend

# Navigate to app directory
cd ~/app/backend

# Install dependencies
echo "Installing dependencies..."
npm install --production

# Create production environment file if it doesn't exist
if [ ! -f .env ]; then
    echo "Creating production environment file..."
    cat > .env << 'EOL'
# Server Configuration
PORT=5000
NODE_ENV=production

MONGODB_URI=mongodb+srv://admin:MW2Ovg4SJ1j998UQ@cluster0.fezie.mongodb.net/ooh
JWT_SECRET=oohbox_secret@2664
JWT_EXPIRE=30d

AWS_ACCESS_KEY_ID=AKIAQVF7OEMVSBU5FZYV
AWS_SECRET_ACCESS_KEY=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
AWS_REGION=eu-north-1
AWS_BUCKET_NAME=hoarding-booking-images

FRONTEND_URL=http://13.60.215.0

CORS_ORIGIN=http://13.60.215.0

LOG_LEVEL=info

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000  # 15 minutes
RATE_LIMIT_MAX_REQUESTS=100  # maximum 100 requests per window

# Logging
LOG_LEVEL=info
EOL
fi

# Start or restart the application with PM2
echo "Starting application with PM2..."
pm2 delete backend || true
pm2 start src/server.js --name backend

# Save PM2 process list
pm2 save

# Setup PM2 to start on system boot
pm2 startup

echo "Deployment completed successfully!" 